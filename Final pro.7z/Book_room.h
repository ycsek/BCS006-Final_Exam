/*
 * @Author: Yuchen Shi
 * @Date: 27-04-2024 20:27:11
 * @LastEditors: Jason
 * @Contact LastEditors: yuchenshi327@outlook.com
 * @LastEditTime: 30-04-2024 16:15:42
 */


#ifndef BOOK_ROOM_H
#define BOOK_ROOM_H

void book_room();

#endif // BOOK_ROOM_H