/*
 * @Author: Yuchen Shi
 * @Date: 27-04-2024 20:25:48
 * @LastEditors: Jason
 * @Contact LastEditors: yuchenshi327@outlook.com
 * @LastEditTime: 30-04-2024 16:16:03
 */

#ifndef CHECK_IN_H
#define CHECK_IN_H

void check_in();

#endif // CHECK_IN_H