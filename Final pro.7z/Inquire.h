/*
 * @Author: Yuchen Shi
 * @Date: 27-04-2024 20:27:45
 * @LastEditors: Jason
 * @Contact LastEditors: yuchenshi327@outlook.com
 * @LastEditTime: 30-04-2024 16:18:16
 */


#ifndef INQUIRE_H
#define INQUIRE_H

void inquire();

#endif // INQUIRE_H