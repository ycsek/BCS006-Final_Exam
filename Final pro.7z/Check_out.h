/*
 * @Author: Yuchen Shi
 * @Date: 27-04-2024 20:26:09
 * @LastEditors: Jason
 * @Contact LastEditors: yuchenshi327@outlook.com
 * @LastEditTime: 30-04-2024 16:16:24
 */

#ifndef CHECK_OUT_H
#define CHECK_OUT_H

void check_out();

#endif // CHECK_OUT_H
