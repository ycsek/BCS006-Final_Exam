/*
 * @Author: Yuchen Shi
 * @Date: 27-04-2024 20:27:25
 * @LastEditors: Jason
 * @Contact LastEditors: yuchenshi327@outlook.com
 * @LastEditTime: 30-04-2024 16:17:16
 */

#ifndef ENTER_H
#define ENTER_H

void enter();

#endif // ENTER_H
