/*
 * @Author: Yuchen Shi
 * @Date: 29-04-2024 19:38:13
 * @LastEditors: Jason
 * @Contact LastEditors: yuchenshi327@outlook.com
 * @LastEditTime: 04-05-2024 19:03:09
 */

#include "Global.h"
#include <iostream>

using namespace std;

//定义全局变量
Customer* customer[100];//顾客的指针数组
Room room[100];
int i = 0;

