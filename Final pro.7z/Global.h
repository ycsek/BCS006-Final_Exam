/*
 * @Author: Yuchen Shi
 * @Date: 27-04-2024 21:45:41
 * @LastEditors: Jason
 * @Contact LastEditors: yuchenshi327@outlook.com
 * @LastEditTime: 30-04-2024 16:17:35
 */

 #ifndef GLOBAL_H
 #define GLOBAL_H

 #include "Room.h"
 #include "Customer.h"

//声明全局变量
extern Room room[100];
extern Customer* customer[100];
extern int i;

 #endif // GLOBAL_H
