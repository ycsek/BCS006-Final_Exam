/*
 * @Author: Yuchen Shi
 * @Date: 29-04-2024 19:24:59
 * @LastEditors: Jason
 * @Contact LastEditors: yuchenshi327@outlook.com
 * @LastEditTime: 04-05-2024 19:08:38
 */

#include <iostream>
#include "room.h"
using namespace std;
