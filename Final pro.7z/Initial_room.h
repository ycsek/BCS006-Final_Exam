/*
 * @Author: Yuchen Shi
 * @Date: 27-04-2024 21:06:27
 * @LastEditors: Jason
 * @Contact LastEditors: yuchenshi327@outlook.com
 * @LastEditTime: 30-04-2024 16:18:03
 */


#ifndef INITIAL_ROOM_H
#define INITIAL_ROOM_H

#include <iostream>

void initial_room();

#endif
